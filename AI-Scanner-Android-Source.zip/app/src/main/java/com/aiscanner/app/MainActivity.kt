package com.aiscanner.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF9B5CFF)
private val Dark = Color(0xFF100B20)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Dark, surface = Color(0xFF211637))) {
                ScannerHome(
                    onEnableOverlay = {
                        if (!Settings.canDrawOverlays(this)) {
                            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                            startActivity(intent)
                        } else {
                            startService(Intent(this, FloatingService::class.java))
                        }
                    },
                    overlayAllowed = Settings.canDrawOverlays(this)
                )
            }
        }
    }
}

@Composable
private fun ScannerHome(onEnableOverlay: () -> Unit, overlayAllowed: Boolean) {
    var showInfo by remember { mutableStateOf(false) }
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF241044), Dark, Color(0xFF080611)))).padding(22.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("AI SCANNER", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Quét câu hỏi • Giải thích • Lưu lịch sử", color = Color(0xFFD7C9F5))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF211637)), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Trợ lý nổi Android", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (overlayAllowed) "Quyền hiển thị trên ứng dụng khác đã được cấp." else "Cần cấp quyền hiển thị trên ứng dụng khác để bật nút nổi.",
                        color = Color(0xFFD7C9F5)
                    )
                    Button(onClick = onEnableOverlay, modifier = Modifier.fillMaxWidth()) {
                        Text(if (overlayAllowed) "Bật nút nổi" else "Cấp quyền và bật nút nổi")
                    }
                }
            }
            OutlinedButton(onClick = { showInfo = true }) { Text("Thông tin phiên bản") }
            Text("Phiên bản khởi tạo 0.1.0", color = Color(0xFF9F91B8), fontSize = 12.sp)
        }
        if (showInfo) AlertDialog(
            onDismissRequest = { showInfo = false },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Đóng") } },
            title = { Text("AI Scanner 0.1.0") },
            text = { Text("Đây là bộ khung Android native. Chức năng chụp vùng màn hình, gửi AI Cloud và đăng nhập Supabase sẽ được tích hợp ở các bước tiếp theo; hiện chưa thực hiện quét hay gửi ảnh.") }
        )
    }
}
