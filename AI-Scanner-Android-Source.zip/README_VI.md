# AI Scanner Android — bản khởi tạo 0.1.0

## Có trong bản này
- Ứng dụng Android native bằng Kotlin.
- Giao diện neon tím.
- Xin quyền hiển thị trên ứng dụng khác.
- Dịch vụ nút nổi Android và thông báo foreground.

## Chưa có (không giả lập)
- Chụp màn hình bằng MediaProjection và chọn vùng crop.
- OCR/vision và gửi ảnh lên AI Cloud.
- Đăng nhập username/password qua backend.
- Lịch sử đồng bộ và ứng dụng AI Scanner Admin.

Các phần trên cần backend bảo mật và sẽ được tích hợp tiếp. Không đặt Supabase secret/service-role hoặc khóa AI trong ứng dụng Android.

## Build APK
Có thể tải project lên GitHub bằng điện thoại rồi dùng GitHub Actions/Android Gradle build để tạo APK. Mở repo → Actions → chọn workflow Android Build (cần thêm workflow nếu chưa có).
